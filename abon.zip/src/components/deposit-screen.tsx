import { useEffect, useRef, useState } from "react";

const CODE_LENGTH = 16;
const DEPOSIT = 10;
const SCAN_CODE = "4829163057281640";

const KEYS: { digit: string; letters: string }[] = [
  { digit: "1", letters: "" },
  { digit: "2", letters: "A B C" },
  { digit: "3", letters: "D E F" },
  { digit: "4", letters: "G H I" },
  { digit: "5", letters: "J K L" },
  { digit: "6", letters: "M N O" },
  { digit: "7", letters: "P Q R S" },
  { digit: "8", letters: "T U V" },
  { digit: "9", letters: "W X Y Z" },
];

let audioCtx: AudioContext | null = null;

function formatEur(amount: number) {
  return amount.toFixed(2).replace(".", ",");
}

function formatCode(code: string) {
  return code.match(/.{1,4}/g)?.join(" ") ?? "";
}

function playTap() {
  try {
    const Ctx =
      window.AudioContext ||
      (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    if (!audioCtx) audioCtx = new Ctx();
    if (audioCtx.state === "suspended") void audioCtx.resume();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    const now = audioCtx.currentTime;
    osc.type = "sine";
    osc.frequency.setValueAtTime(160, now);
    osc.frequency.exponentialRampToValueAtTime(45, now + 0.032);
    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.032);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(now + 0.032);
  } catch {
    // Audio can be blocked until a gesture; the keypad still works.
  }
}

export function DepositScreen() {
  const [code, setCode] = useState("");
  const [balance, setBalance] = useState(1);
  const [busy, setBusy] = useState(false);
  const [armed, setArmed] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [toast, setToast] = useState("");
  const [toastKind, setToastKind] = useState<"ok" | "info">("ok");
  const toastTimer = useRef<number | null>(null);
  const armTimer = useRef<number | null>(null);
  const scanTimer = useRef<number | null>(null);
  const codeRef = useRef("");
  const busyRef = useRef(false);
  const pointerArmed = useRef(false);

  const ready = code.length === CODE_LENGTH && !busy;

  function handlePointer(action: () => void) {
    pointerArmed.current = true;
    action();
  }

  function handleClick(action: () => void) {
    if (pointerArmed.current) {
      pointerArmed.current = false;
      return;
    }
    action();
  }

  function commitCode(next: string) {
    codeRef.current = next;
    setCode(next);
  }

  function pressDigit(digit: string) {
    if (busyRef.current || codeRef.current.length >= CODE_LENGTH) return;
    commitCode(codeRef.current + digit);
    playTap();
  }

  function backspace() {
    if (busyRef.current || codeRef.current.length === 0) return;
    commitCode(codeRef.current.slice(0, -1));
    playTap();
  }

  function clearCode() {
    if (busyRef.current || codeRef.current.length === 0) return;
    commitCode("");
    playTap();
  }

  function showToast(message: string, kind: "ok" | "info") {
    setToastKind(kind);
    setToast(message);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), kind === "ok" ? 2500 : 1600);
  }

  function flashField() {
    setArmed(true);
    if (armTimer.current) window.clearTimeout(armTimer.current);
    armTimer.current = window.setTimeout(() => setArmed(false), 300);
  }

  function submit() {
    if (busyRef.current) return;
    if (codeRef.current.length !== CODE_LENGTH) {
      flashField();
      showToast("Zadaj celých 16 číslic.", "info");
      return;
    }
    busyRef.current = true;
    setBusy(true);
    window.setTimeout(() => {
      setBalance((current) => current + DEPOSIT);
      commitCode("");
      busyRef.current = false;
      setBusy(false);
      showToast(`Vklad +${formatEur(DEPOSIT)} EUR bol úspešne spracovaný!`, "ok");
    }, 450);
  }

  function scanCode() {
    if (busyRef.current || scanning) return;
    setScanning(true);
    playTap();
    if (scanTimer.current) window.clearTimeout(scanTimer.current);
    scanTimer.current = window.setTimeout(() => {
      commitCode(SCAN_CODE);
      setScanning(false);
      showToast("QR kód bol načítaný.", "ok");
    }, 280);
  }

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.metaKey || event.ctrlKey || event.altKey) return;
      if (event.key >= "0" && event.key <= "9") {
        event.preventDefault();
        pressDigit(event.key);
      } else if (event.key === "Backspace") {
        event.preventDefault();
        backspace();
      } else if (event.key === "Enter") {
        event.preventDefault();
        submit();
      } else if (event.key === "Escape") {
        event.preventDefault();
        clearCode();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
      if (armTimer.current) window.clearTimeout(armTimer.current);
      if (scanTimer.current) window.clearTimeout(scanTimer.current);
    };
    // Keyboard listener reads the latest code through refs.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <main className="shell">
      <div
        className="toast"
        data-open={toast ? "true" : "false"}
        data-kind={toastKind}
        role="status"
        aria-live="polite"
      >
        {toastKind === "ok" ? (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M5 13l4 4L19 7" />
          </svg>
        ) : null}
        <span>{toast || " "}</span>
      </div>

      <section className="top">
        <div className="copy">
          <h1 className="screen-title">Vklad</h1>
          <p className="balance">
            Zostatok: <span>{formatEur(balance)}</span> EUR
          </p>
          <p className="hint">Naskenuj QR kód a vykonaj vklad</p>
        </div>
        <div className="finder-slot">
          <button
            type="button"
            className="finder"
            data-scanning={scanning ? "true" : "false"}
            aria-label="Naskenovať QR kód"
            onPointerDown={() => handlePointer(scanCode)}
            onClick={() => handleClick(scanCode)}
          />
        </div>
      </section>

      <section className="bottom">
        <div className="sheet">
          <div className="sheet-head">
            <h2 className="sheet-title">Zadať kód ručne</h2>
            <button
              type="button"
              className="icon-btn"
              aria-label="Vymazať zadaný kód"
              onPointerDown={() => handlePointer(clearCode)}
              onClick={() => handleClick(clearCode)}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
                <path strokeLinecap="round" strokeWidth="2.4" d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
          </div>

          <button
            type="button"
            className="code-field"
            data-armed={armed ? "true" : "false"}
            onPointerDown={() => handlePointer(flashField)}
            onClick={() => handleClick(flashField)}
            aria-label="Zadaj 16-miestny kód"
          >
            <span className="code-label">Zadaj 16-miestny kód</span>
            <span className="code-row">
              <span className="code-digits">{formatCode(code)}</span>
              <span className="caret" aria-hidden="true" />
            </span>
          </button>

          <div className="submit-wrap">
            <button
              type="button"
              className="submit"
              data-ready={ready || busy ? "true" : "false"}
              onPointerDown={() => handlePointer(submit)}
              onClick={() => handleClick(submit)}
            >
              {busy ? <span className="spinner" aria-hidden="true" /> : "Vykonať vklad"}
            </button>
          </div>
        </div>

        <div className="keypad">
          <div className="key-grid">
            {KEYS.map((key) => (
              <button
                key={key.digit}
                type="button"
                className="key"
                aria-label={key.digit}
                onPointerDown={() => handlePointer(() => pressDigit(key.digit))}
                onClick={() => handleClick(() => pressDigit(key.digit))}
              >
                <span className="key-digit">{key.digit}</span>
                <span className="key-sub">{key.letters}</span>
              </button>
            ))}
            <div className="key-gap" aria-hidden="true" />
            <button
              type="button"
              className="key"
              aria-label="0"
              onPointerDown={() => handlePointer(() => pressDigit("0"))}
              onClick={() => handleClick(() => pressDigit("0"))}
            >
              <span className="key-digit">0</span>
              <span className="key-sub" />
            </button>
            <button
              type="button"
              className="backspace"
              aria-label="Zmazať číslicu"
              onPointerDown={() => handlePointer(backspace)}
              onClick={() => handleClick(backspace)}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.8"
                  d="M12 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2M3 12l6.5-7.5H20a2 2 0 012 2v11a2 2 0 01-2 2H9.5L3 12z"
                />
              </svg>
            </button>
          </div>
          <div className="home-pill" aria-hidden="true" />
        </div>
      </section>
    </main>
  );
}
