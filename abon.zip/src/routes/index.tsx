import { createFileRoute } from "@tanstack/react-router";
import { DepositScreen } from "@/components/deposit-screen";

export const Route = createFileRoute("/")({ component: DepositScreen });
