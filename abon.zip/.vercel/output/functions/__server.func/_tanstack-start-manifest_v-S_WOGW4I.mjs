//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-S_WOGW4I.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Bdjmh8Sj.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bdjmh8Sj.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-A2QeEQ0F.js"]
	}
} });
//#endregion
export { tsrStartManifest };
