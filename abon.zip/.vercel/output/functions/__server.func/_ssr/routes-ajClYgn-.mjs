import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ajClYgn-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CODE_LENGTH = 16;
var DEPOSIT = 10;
var SCAN_CODE = "4829163057281640";
var KEYS = [
	{
		digit: "1",
		letters: ""
	},
	{
		digit: "2",
		letters: "A B C"
	},
	{
		digit: "3",
		letters: "D E F"
	},
	{
		digit: "4",
		letters: "G H I"
	},
	{
		digit: "5",
		letters: "J K L"
	},
	{
		digit: "6",
		letters: "M N O"
	},
	{
		digit: "7",
		letters: "P Q R S"
	},
	{
		digit: "8",
		letters: "T U V"
	},
	{
		digit: "9",
		letters: "W X Y Z"
	}
];
var audioCtx = null;
function formatEur(amount) {
	return amount.toFixed(2).replace(".", ",");
}
function formatCode(code) {
	return code.match(/.{1,4}/g)?.join(" ") ?? "";
}
function playTap() {
	try {
		const Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx) return;
		if (!audioCtx) audioCtx = new Ctx();
		if (audioCtx.state === "suspended") audioCtx.resume();
		const osc = audioCtx.createOscillator();
		const gain = audioCtx.createGain();
		const now = audioCtx.currentTime;
		osc.type = "sine";
		osc.frequency.setValueAtTime(160, now);
		osc.frequency.exponentialRampToValueAtTime(45, now + .032);
		gain.gain.setValueAtTime(.08, now);
		gain.gain.exponentialRampToValueAtTime(.001, now + .032);
		osc.connect(gain);
		gain.connect(audioCtx.destination);
		osc.start();
		osc.stop(now + .032);
	} catch {}
}
function DepositScreen() {
	const [code, setCode] = (0, import_react.useState)("");
	const [balance, setBalance] = (0, import_react.useState)(1);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [armed, setArmed] = (0, import_react.useState)(false);
	const [scanning, setScanning] = (0, import_react.useState)(false);
	const [toast, setToast] = (0, import_react.useState)("");
	const [toastKind, setToastKind] = (0, import_react.useState)("ok");
	const toastTimer = (0, import_react.useRef)(null);
	const armTimer = (0, import_react.useRef)(null);
	const scanTimer = (0, import_react.useRef)(null);
	const codeRef = (0, import_react.useRef)("");
	const busyRef = (0, import_react.useRef)(false);
	const pointerArmed = (0, import_react.useRef)(false);
	const ready = code.length === CODE_LENGTH && !busy;
	function handlePointer(action) {
		pointerArmed.current = true;
		action();
	}
	function handleClick(action) {
		if (pointerArmed.current) {
			pointerArmed.current = false;
			return;
		}
		action();
	}
	function commitCode(next) {
		codeRef.current = next;
		setCode(next);
	}
	function pressDigit(digit) {
		if (busyRef.current || codeRef.current.length >= CODE_LENGTH) return;
		commitCode(codeRef.current + digit);
		playTap();
	}
	function backspace() {
		if (busyRef.current || codeRef.current.length === 0) return;
		commitCode(codeRef.current.slice(0, -1));
		playTap();
	}
	function clearCode() {
		if (busyRef.current || codeRef.current.length === 0) return;
		commitCode("");
		playTap();
	}
	function showToast(message, kind) {
		setToastKind(kind);
		setToast(message);
		if (toastTimer.current) window.clearTimeout(toastTimer.current);
		toastTimer.current = window.setTimeout(() => setToast(""), kind === "ok" ? 2500 : 1600);
	}
	function flashField() {
		setArmed(true);
		if (armTimer.current) window.clearTimeout(armTimer.current);
		armTimer.current = window.setTimeout(() => setArmed(false), 300);
	}
	function submit() {
		if (busyRef.current) return;
		if (codeRef.current.length !== CODE_LENGTH) {
			flashField();
			showToast("Zadaj celých 16 číslic.", "info");
			return;
		}
		busyRef.current = true;
		setBusy(true);
		window.setTimeout(() => {
			setBalance((current) => current + DEPOSIT);
			commitCode("");
			busyRef.current = false;
			setBusy(false);
			showToast(`Vklad +${formatEur(DEPOSIT)} EUR bol úspešne spracovaný!`, "ok");
		}, 450);
	}
	function scanCode() {
		if (busyRef.current || scanning) return;
		setScanning(true);
		playTap();
		if (scanTimer.current) window.clearTimeout(scanTimer.current);
		scanTimer.current = window.setTimeout(() => {
			commitCode(SCAN_CODE);
			setScanning(false);
			showToast("QR kód bol načítaný.", "ok");
		}, 280);
	}
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (event.metaKey || event.ctrlKey || event.altKey) return;
			if (event.key >= "0" && event.key <= "9") {
				event.preventDefault();
				pressDigit(event.key);
			} else if (event.key === "Backspace") {
				event.preventDefault();
				backspace();
			} else if (event.key === "Enter") {
				event.preventDefault();
				submit();
			} else if (event.key === "Escape") {
				event.preventDefault();
				clearCode();
			}
		}
		window.addEventListener("keydown", onKey);
		return () => {
			window.removeEventListener("keydown", onKey);
			if (toastTimer.current) window.clearTimeout(toastTimer.current);
			if (armTimer.current) window.clearTimeout(armTimer.current);
			if (scanTimer.current) window.clearTimeout(scanTimer.current);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "shell",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "toast",
				"data-open": toast ? "true" : "false",
				"data-kind": toastKind,
				role: "status",
				"aria-live": "polite",
				children: [toastKind === "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 24 24",
					fill: "none",
					stroke: "currentColor",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						strokeLinecap: "round",
						strokeLinejoin: "round",
						strokeWidth: "2.5",
						d: "M5 13l4 4L19 7"
					})
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: toast || " " })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "top",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "copy",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "screen-title",
							children: "Vklad"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "balance",
							children: [
								"Zostatok: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatEur(balance) }),
								" EUR"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hint",
							children: "Naskenuj QR kód a vykonaj vklad"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "finder-slot",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "finder",
						"data-scanning": scanning ? "true" : "false",
						"aria-label": "Naskenovať QR kód",
						onPointerDown: () => handlePointer(scanCode),
						onClick: () => handleClick(scanCode)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "bottom",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sheet",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sheet-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "sheet-title",
								children: "Zadať kód ručne"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "icon-btn",
								"aria-label": "Vymazať zadaný kód",
								onPointerDown: () => handlePointer(clearCode),
								onClick: () => handleClick(clearCode),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									"aria-hidden": "true",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										strokeLinecap: "round",
										strokeWidth: "2.4",
										d: "M6 6l12 12M18 6L6 18"
									})
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "code-field",
							"data-armed": armed ? "true" : "false",
							onPointerDown: () => handlePointer(flashField),
							onClick: () => handleClick(flashField),
							"aria-label": "Zadaj 16-miestny kód",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "code-label",
								children: "Zadaj 16-miestny kód"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "code-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "code-digits",
									children: formatCode(code)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "caret",
									"aria-hidden": "true"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "submit-wrap",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "submit",
								"data-ready": ready || busy ? "true" : "false",
								onPointerDown: () => handlePointer(submit),
								onClick: () => handleClick(submit),
								children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "spinner",
									"aria-hidden": "true"
								}) : "Vykonať vklad"
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "keypad",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "key-grid",
						children: [
							KEYS.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "key",
								"aria-label": key.digit,
								onPointerDown: () => handlePointer(() => pressDigit(key.digit)),
								onClick: () => handleClick(() => pressDigit(key.digit)),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "key-digit",
									children: key.digit
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "key-sub",
									children: key.letters
								})]
							}, key.digit)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "key-gap",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "key",
								"aria-label": "0",
								onPointerDown: () => handlePointer(() => pressDigit("0")),
								onClick: () => handleClick(() => pressDigit("0")),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "key-digit",
									children: "0"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "key-sub" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "backspace",
								"aria-label": "Zmazať číslicu",
								onPointerDown: () => handlePointer(backspace),
								onClick: () => handleClick(backspace),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									"aria-hidden": "true",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "1.8",
										d: "M12 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2M3 12l6.5-7.5H20a2 2 0 012 2v11a2 2 0 01-2 2H9.5L3 12z"
									})
								})
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "home-pill",
						"aria-hidden": "true"
					})]
				})]
			})
		]
	});
}
var SplitComponent = DepositScreen;
//#endregion
export { SplitComponent as component };
